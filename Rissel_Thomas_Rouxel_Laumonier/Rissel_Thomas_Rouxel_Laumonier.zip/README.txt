Le Makefile a été généré à l'aide de CMake en utilisant MinGW.

Pour plus de lisibilité des captures d'écrans du rapport, vous trouverez notre diagramme UML dans les fichiers rendus.