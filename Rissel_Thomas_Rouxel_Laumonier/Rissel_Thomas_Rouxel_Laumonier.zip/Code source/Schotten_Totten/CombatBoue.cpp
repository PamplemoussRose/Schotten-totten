#include "CombatBoue.h"

vector<vector<unsigned int>> CombatBoue::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void CombatBoue::effet(unsigned int borne) {

}