#include "Banschee.h"

vector<vector<unsigned int>> Banschee::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void Banschee::effet(unsigned int borne, unsigned int carte, unsigned int joueur) {
	if (joueur == 1) {

	}
	else if (joueur == 2) {

	}
	else {
		throw new exception("Joueur non valide");
	}
}