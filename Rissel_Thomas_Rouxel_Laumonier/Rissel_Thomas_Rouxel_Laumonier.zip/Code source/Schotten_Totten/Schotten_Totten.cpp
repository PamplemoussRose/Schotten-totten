#include <iostream>
#include "Application.h"
#include "Test.h"

int main()
{
    /* Lancement application*/
    /*
    Application app;
    app.mainloop();
    */
    std::cout << "Hello World!\n";
    Test::test();
    Test::testLancementApp();
}