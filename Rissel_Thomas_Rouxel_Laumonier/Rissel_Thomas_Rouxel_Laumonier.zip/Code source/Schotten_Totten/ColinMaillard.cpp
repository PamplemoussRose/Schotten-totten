#include "ColinMaillard.h"

vector<vector<unsigned int>> ColinMaillard::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void ColinMaillard::effet(unsigned int borne) {

}