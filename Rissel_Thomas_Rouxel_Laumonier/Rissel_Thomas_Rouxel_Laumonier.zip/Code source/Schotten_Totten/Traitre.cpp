#include "Traitre.h"

vector<vector<unsigned int>> Traitre::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void Traitre::effet(unsigned int borneAdverse, unsigned int carte, unsigned int borneAliee, unsigned int joueur) {
	if (joueur == 1) {

	}
	else if (joueur == 2) {

	}
	else {
		throw new exception("Joueur non valide");
	}
}