#include "ChasseurTete.h"

vector<vector<unsigned int>> ChasseurTete::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void ChasseurTete::effet(unsigned int carte1, unsigned int carte2, unsigned int joueur) {
	if (joueur == 1) {

	}
	else if (joueur == 2) {

	}
	else {
		throw new exception("Joueur non valide");
	}
	
}