#ifndef CONTROLEURVICTOIRE_H
#define CONTROLEURVOCTOIRE_H

class ControleurVictoire {
public:
	/*!
	* retourne 1 si joueur 1 gagnant ou 2 si joueur 2 gagnant
	*/
	static unsigned int estGagnant();
};

#endif // !CONTROEURVICTOIRE_H


