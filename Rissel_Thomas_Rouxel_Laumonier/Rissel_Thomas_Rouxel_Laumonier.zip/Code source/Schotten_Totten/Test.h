#ifndef TEST_H
#define TEST_H

#include "Plateau.h"
#include "Couleurs.h"
#include "Application.h"
#include "ControleurVariante.h"

#include <iostream>
using namespace std;
/**
* Classe pour faire les test du projet
*/

class Test
{
public:
	static void test();
	static void testLancementApp();
};

#endif // !TEST_H
