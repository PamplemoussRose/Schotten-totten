#ifndef PIOCHECLAN_HEADER
#define PIOCHECLAN_HEADER
#include "CarteClan.h"
#include "Pioche.h"

class Pioche;
class CarteClan;

class PiocheClan : public Pioche {

public:
	//constructeur
	/*!
	* \brief construit la pioche de carte clan
	*/
	PiocheClan();
};
#endif