#include "Stratege.h"

vector<vector<unsigned int>> Stratege::choixEffet() {
	/* RECUPERATION DES CHOIX */
	return vector<vector<unsigned int>>();
}

void Stratege::effet(unsigned int borneDep, unsigned int carte, unsigned int borneArr, unsigned int joueur) {
	if (joueur == 1) {

	}
	else if (joueur == 2) {

	}
	else {
		throw new exception("Joueur non valide");
	}

}

void Stratege::effet(unsigned int borne, unsigned int carte, unsigned int joueur) {
	if (joueur == 1) {

	}
	else if (joueur == 2) {

	}
	else {
		throw new exception("Joueur non valide");
	}
}